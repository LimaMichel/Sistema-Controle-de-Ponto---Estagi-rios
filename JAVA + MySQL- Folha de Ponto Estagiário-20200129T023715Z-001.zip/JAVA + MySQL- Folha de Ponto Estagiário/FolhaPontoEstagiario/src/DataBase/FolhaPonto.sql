CREATE DATABASE FolhadePonto;

USE FolhadePonto;
SELECT @@VERSION_COMMENT;


/*

DROP DATABASE FolhadePonto;

DROP TABLE T_ORGANIZACAO;
DROP TABLE T_SETOR;
DROP TABLE T_ESTAGIARIO;
DROP TABLE T_ENDERECO;
DROP TABLE T_TELEFONE;
DROP TABLE T_FOLHA_PONTO;
DROP TABLE T_PONTO_ASSINADO;

*/

CREATE TABLE T_ORGANIZACAO
(
    cd_org SMALLINT PRIMARY KEY AUTO_INCREMENT,  
    razao_social VARCHAR(100) NOT NULL,
    cnpj CHAR(18) NOT NULL,
    ds_email VARCHAR(40) NOT NULL
)ENGINE = innodb;

/*UNIQUE*/
ALTER TABLE T_ORGANIZACAO
ADD CONSTRAINT UN_ORG
UNIQUE(cnpj,ds_email);

/*
-----------------------------------------------------------
*/


CREATE TABLE T_SUPERVISOR
(
    cd_supervisor SMALLINT PRIMARY KEY AUTO_INCREMENT,
    rf_supervisor VARCHAR(50) NOT NULL,
    cd_org SMALLINT NOT NULL,
    nome_supervisor VARCHAR(50) NOT NULL,
    dt_admis VARCHAR(50) NOT NULL
)ENGINE = innodb;

/*UNIQUE*/
ALTER TABLE T_SUPERVISOR
ADD CONSTRAINT UN_SUP
UNIQUE(rf_supervisor);

/*CHAVE ESTRANGEIRA*/
ALTER TABLE T_SUPERVISOR
ADD CONSTRAINT FK_SUPERVISOR
FOREIGN KEY(cd_org)
REFERENCES T_ORGANIZACAO(cd_org)
ON DELETE CASCADE on update cascade;

/*
-----------------------------------------------------------
*/


CREATE TABLE T_SETOR
(
    cd_setor INT PRIMARY KEY AUTO_INCREMENT,
    cd_org SMALLINT NOT NULL,
    nm_setor VARCHAR(25) NOT NULL
)ENGINE = innodb;

/*UNIQUE*/
ALTER TABLE T_SETOR
ADD CONSTRAINT UN_SET
UNIQUE(cd_setor);

/*CHAVE ESTRANGEIRA*/
ALTER TABLE T_SETOR
ADD CONSTRAINT FK_SETOR
FOREIGN KEY(cd_org)
REFERENCES T_ORGANIZACAO(cd_org)
ON DELETE CASCADE on update cascade;

/*
-----------------------------------------------------------
*/


CREATE TABLE T_ESTAGIARIO
(
    cd_estagiario SMALLINT PRIMARY KEY AUTO_INCREMENT,
    cd_setor INT NOT NULL,
    nm_estagiario VARCHAR(40) NOT NULL,
    ds_sexo CHAR(1) NOT NULL,
    rg_estagiario CHAR(9) NOT NULL,
    dt_nascimento CHAR(10) NOT NULL,
    dt_admissao CHAR(10) NOT NULL
)ENGINE = innodb;

/*UNIQUE*/
ALTER TABLE T_ESTAGIARIO
ADD CONSTRAINT UN_EST
UNIQUE(rg_estagiario);

/*CHAVE ESTRANGEIRA*/
ALTER TABLE T_ESTAGIARIO
ADD CONSTRAINT FK_ESTAGIARIO
FOREIGN KEY(cd_setor)
REFERENCES T_SETOR(cd_setor)
ON DELETE CASCADE on update cascade;

/*
-----------------------------------------------------------
*/

CREATE TABLE T_FOLHA_PONTO
(
    cd_fp int primary key auto_increment,
    dt_folha_ponto VARCHAR(15) NOT NULL,
    cd_estagiario SMALLINT NOT NULL,
    situacao VARCHAR(20) NOT NULL
)ENGINE = innodb;

/*CHAVE ESTRANGEIRA*/
ALTER TABLE T_FOLHA_PONTO
ADD CONSTRAINT FK_FOLHA_PONTO
FOREIGN KEY(cd_estagiario)
REFERENCES T_ESTAGIARIO(cd_estagiario)
ON DELETE CASCADE on update cascade;

/*
-----------------------------------------------------------
*/

CREATE TABLE T_PONTO_ASSINADO
(

 cd_ponto_ass int primary key auto_increment,
 hr_entrada CHAR(5) NOT NULL,
 hr_saida CHAR(5) NOT NULL,
 obs VARCHAR(60) NOT NULL,
 cd_fp INT NOT NULL,
 dt_folha_ponto VARCHAR(20) NOT NULL

)ENGINE = innodb;

/*CHAVE ESTRANGEIRA*/
ALTER TABLE T_PONTO_ASSINADO
ADD CONSTRAINT FK_PONTO_ASSINADO
FOREIGN KEY(cd_fp)
REFERENCES T_FOLHA_PONTO(cd_fp)
ON DELETE CASCADE on update cascade;

/*
-----------------------------------------------------------
*/


CREATE TABLE T_ENDERECO
(
    cd_endereco INT PRIMARY KEY AUTO_INCREMENT,
    ds_bairro VARCHAR(20) NOT NULL,
    tipo_logradouro VARCHAR(60) NOT NULL,
    ds_logradouro VARCHAR(40) NOT NULL,
    numero NUMERIC(5) NOT NULL,
    complemento VARCHAR(10),
    cep CHAR(9) NOT NULL,
    cd_org SMALLINT
)ENGINE = innodb;

/*UNIQUE*/
ALTER TABLE T_ENDERECO
ADD CONSTRAINT UN_END
UNIQUE(cep);

/*CHAVES ESTRANGEIRA*/
ALTER TABLE T_ENDERECO
ADD CONSTRAINT FK_ENDERECO
FOREIGN KEY(cd_org)
REFERENCES T_ORGANIZACAO(cd_org)
ON DELETE CASCADE on update cascade;

/*
-----------------------------------------------------------
*/


CREATE TABLE T_TELEFONE
(
    cd_telefone INT PRIMARY KEY AUTO_INCREMENT,
    cd_pais CHAR(3) NOT NULL,
    ddd_telefone NUMERIC(2) NOT NULL,
    nr_telefone NUMERIC(11) NOT NULL,
    cd_setor INT NOT NULL
)ENGINE = innodb;

/*UNIQUE*/
ALTER TABLE T_TELEFONE
ADD CONSTRAINT UN_TEL
UNIQUE(nr_telefone);

/*CHAVE ESTRANGEIRA*/
ALTER TABLE T_TELEFONE
ADD CONSTRAINT FK_TEL
FOREIGN KEY(cd_setor)
REFERENCES T_SETOR(cd_setor)
ON DELETE CASCADE on update cascade;


