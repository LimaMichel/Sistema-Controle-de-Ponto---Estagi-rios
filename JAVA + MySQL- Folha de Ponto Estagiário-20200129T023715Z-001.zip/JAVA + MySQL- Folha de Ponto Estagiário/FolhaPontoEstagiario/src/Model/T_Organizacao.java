/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

/**
 *
 * @author Miche1
 */
public class T_Organizacao {
    
    //variaveis
    private String razaoSocial;
    private String cnpj;
    private String emailOrg;
    
    //construtor
    public T_Organizacao(String razaoSocial,
                          String cnpj,String emailOrg){
        this.razaoSocial = razaoSocial;
        this.cnpj = cnpj;
        this.emailOrg = emailOrg;
    }
    
    //metodos getter e setter
    public String getRazaoSocial() {
        return razaoSocial;
    }

    public String getCnpj() {
        return cnpj;
    }

    public String getEmailOrg() {
        return emailOrg;
    }
    

    public void setRazaoSocial(String razaoSocial) {
        this.razaoSocial = razaoSocial;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public void setEmailOrg(String emailOrg) {
        this.emailOrg = emailOrg;
    }
}
