/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;


import java.text.SimpleDateFormat;
import java.util.Calendar;



/**
 *
 * @author Miche1
 */
public class T_Estagiario {

    //variaveis
    private int codigoSetor;
    private String nomeEstagiario;
    private String sexo; 
    private String rg;
    private String dt_nasto;
    private String dt_admissao;

    
    //construtor
    public T_Estagiario(int codigoSetor, String nomeEstagiario,
                        String sexo, String rg, String dt_nasto, String dt_admissao) {
        this.codigoSetor = codigoSetor;
        this.nomeEstagiario = nomeEstagiario;
        this.sexo = sexo;
        this.rg = rg;
        this.dt_nasto = dt_nasto;
        this.dt_admissao = dt_admissao;
    }
    
    //metodos getter e setter
    public void setCodigoSetor(int codigoSetor) {
        this.codigoSetor = codigoSetor;
    }

    public void setNomeEstagiario(String nomeEstagiario) {
        this.nomeEstagiario = nomeEstagiario;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public void setDt_nasto(String dt_nasto) {
        this.dt_nasto = dt_nasto;
    }

    public void setDt_admissao(String dt_admissao) {
        this.dt_admissao = dt_admissao;
    }


    public int getCodigoSetor() {
        return codigoSetor;
    }

    public String getNomeEstagiario() {
        return nomeEstagiario;
    }

    public String getSexo() {
        return sexo;
    }

    public String getRg() {
        return rg;
    }

    public String getDt_nasto() {
        return dt_nasto;
    }

    public String getDt_admissao() {
        return dt_admissao;
    }
}
