/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

/**
 *
 * @author Miche1
 */
public class T_PontoAssinado {

    private String hr_entrada;
    private String hr_saida;
    private String obs;
    private int cd_fp;
    private String dt_folhaponto;
    
    //construtor
    public T_PontoAssinado(String hr_entrada, String hr_saida, String obs, int cd_fp, String dt_folhaponto) {
        this.hr_entrada = hr_entrada;
        this.hr_saida = hr_saida;
        this.obs = obs;
        this.cd_fp = cd_fp;
        this.dt_folhaponto = dt_folhaponto;
    }
    
    // metodos getter e setter
    public String getHr_entrada() {
        return hr_entrada;
    }

    public void setHr_entrada(String hr_entrada) {
        this.hr_entrada = hr_entrada;
    }

    public String getHr_saida() {
        return hr_saida;
    }

    public void setHr_saida(String hr_saida) {
        this.hr_saida = hr_saida;
    }

    public String getObs() {
        return obs;
    }

    public void setObs(String obs) {
        this.obs = obs;
    }
    
    public int getCd_fp() {
        return cd_fp;
    }

    public void setCd_estagiario(int cd_fp) {
        this.cd_fp = cd_fp;
    }
    
    public String getDt_folhaponto() {
        return dt_folhaponto;
    }

    public void setDt_folhaponto(String dt_folhaponto) {
        this.dt_folhaponto = dt_folhaponto;
    }
}
