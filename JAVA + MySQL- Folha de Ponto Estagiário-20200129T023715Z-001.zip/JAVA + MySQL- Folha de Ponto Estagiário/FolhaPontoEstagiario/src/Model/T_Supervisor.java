/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

/**
 *
 * @author x527556
 */
public class T_Supervisor {
    
    //variaveis
    private String rfSupervisor;
    private int cdOrg;
    private String nomeSupervisor;
    private String dt_admis;
    
    public T_Supervisor(String rfSupervisor, int cdOrg, String nomeSupervisor, String dt_admis) {
        this.rfSupervisor = rfSupervisor;
        this.cdOrg = cdOrg;
        this.nomeSupervisor = nomeSupervisor;
        this.dt_admis = dt_admis;
    }

    public String getRfSupervisor() {
        return rfSupervisor;
    }

    public void setRfSupervisor(String rfSupervisor) {
        this.rfSupervisor = rfSupervisor;
    }

    public int getCdOrg() {
        return cdOrg;
    }

    public void setCdOrg(int cdSetor) {
        this.cdOrg = cdSetor;
    }

    public String getNomeSupervisor() {
        return nomeSupervisor;
    }

    public void setNomeSupervisor(String nomeSupervisor) {
        this.nomeSupervisor = nomeSupervisor;
    }

    public String getDt_admis() {
        return dt_admis;
    }

    public void setDt_admis(String dt_admis) {
        this.dt_admis = dt_admis;
    }
    
    
}
