/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

/**
 *
 * @author Miche1
 */
public class T_FolhadePonto {
    
    //variaveis
    private String dt_folhaponto;
    private int cd_estagiario;
    private String situacao;
    
    //construtor
    public T_FolhadePonto( String dt_folhaponto, int cd_estagiario, String situacao) {
        this.dt_folhaponto = dt_folhaponto;
        this.cd_estagiario = cd_estagiario;
        this.situacao = situacao;
    }
    
    //metodos getter e setter
    
    public String getDt_folhaponto() {
        return dt_folhaponto;
    }

    public void setDt_folhaponto(String dt_folhaponto) {
        this.dt_folhaponto = dt_folhaponto;
    }

    public int getCd_estagiario() {
        return cd_estagiario;
    }

    public void setCd_estagiario(int cd_estagiario) {
        this.cd_estagiario = cd_estagiario;
    }
    
    public String getSituacao() {
        return situacao;
    }

    public void setSituacao(String situacao) {
        this.situacao = situacao;
    }
}
