/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

/**
 *
 * @author Miche1
 */
public class T_Telefone {
    
    //variaveis
    private String codigoPais;
    private int dddTelefone;
    private int numeroTelefone;
    private int codSetor;
            
    //construtor
    public T_Telefone(String codigoPais, int dddTelefone, int numeroTelefone, int codSetor) {
        this.codigoPais = codigoPais;
        this.dddTelefone = dddTelefone;
        this.numeroTelefone = numeroTelefone;
        this.codSetor = codSetor;
    }
    
    //metodos getter e setter
    public String getCodigoPais() {
        return codigoPais;
    }

    public int getDddTelefone() {
        return dddTelefone;
    }

    public int getNumeroTelefone() {
        return numeroTelefone;
    }


    public int getCodSetor() {
        return codSetor;
    }
    

    public void setCodigoPais(String codigoPais) {
        this.codigoPais = codigoPais;
    }

    public void setDddTelefone(int dddTelefone) {
        this.dddTelefone = dddTelefone;
    }

    public void setNumeroTelefone(int numeroTelefone) {
        this.numeroTelefone = numeroTelefone;
    }

    public void setCodSetor(int codSetor) {
        this.codSetor = codSetor;
    }
}
