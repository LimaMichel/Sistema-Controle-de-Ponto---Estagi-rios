/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

/**
 *
 * @author Miche1
 */
public class T_Setor {
    
    //variaveis
    private String nomeSetor;
    
    //construtor
    public T_Setor(String nomeSetor){
        this.nomeSetor = nomeSetor;
    }
    
    //metodos getter e setter
    public String getNomeSetor() {
        return nomeSetor;
    }

    public void setNomeSetor(String nomeSetor) {
        this.nomeSetor = nomeSetor;
    }
}
