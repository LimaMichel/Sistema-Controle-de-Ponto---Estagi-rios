/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

/**
 *
 * @author Miche1
 */
public class T_Endereco {
    
    //variaveis
    private String bairro;
    private String logradouro;
    private String dsLogradouro;
    private int numero;
    private String complemento;
    private String cep; 
    
    //construtor
    public T_Endereco(String bairro,  String logradouro, String dsLogradouro,
                      int numero, String complemento, String cep){
        this.bairro = bairro;
        this.logradouro = logradouro;
        this.dsLogradouro = dsLogradouro;
        this.numero = numero;
        this.complemento = complemento;
        this.cep = cep; 
    }
    
    //metodos getter e setter
    public String getBairro() {
        return bairro;
    }
    
    public String getLogradouro() {
        return logradouro;
    }

    public String getDsLogradouro() {
        return dsLogradouro;
    }

    public int getNumero() {
        return numero;
    }

    public String getComplemento() {
        return complemento;
    }

    public String getCep() {
        return cep;
    }
    

    
    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public void setDsLogradouro(String dsLogradouro) {
        this.dsLogradouro = dsLogradouro;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }
}
