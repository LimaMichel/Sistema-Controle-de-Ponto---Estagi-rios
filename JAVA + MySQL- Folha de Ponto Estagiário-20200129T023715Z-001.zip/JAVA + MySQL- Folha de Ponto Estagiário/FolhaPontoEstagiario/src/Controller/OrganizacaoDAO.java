/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Controller;

import DataBase.ConnectionFactory;
import Model.T_Organizacao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Miche1
 */

public class OrganizacaoDAO {
    String sql,sql2;
    public void inserir(T_Organizacao organizacao) throws SQLException{
        
        Connection connection =  ConnectionFactory.getConnection();
        sql = "INSERT INTO T_ORGANIZACAO VALUES (null,?,?,?)";
        PreparedStatement pst = connection.prepareStatement(sql);
        try{
            pst.setString(1, organizacao.getRazaoSocial());
            pst.setString(2, organizacao.getCnpj());
            pst.setString(3, organizacao.getEmailOrg());
            
            pst.executeUpdate();
	    pst.close();
        }
        finally{
            connection.close();
        }
    }
    
    public void atualizar(T_Organizacao organizacao, JLabel lbl) throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
	PreparedStatement ps;
	
        try{
		
            ps = connection.prepareStatement("UPDATE T_ORGANIZACAO SET razao_social=?, cnpj=?, ds_email=? WHERE cd_org=?");
	    	
            ps.setString(1, organizacao.getRazaoSocial());
            ps.setString(2, organizacao.getCnpj());
            ps.setString(3, organizacao.getEmailOrg());
            ps.setInt(4, Integer.parseInt(lbl.getText()));
            
            ps.executeUpdate();
            ps.close();
        }
        finally{
            connection.close();
	}
    }
    
    public void pesquisar(JTable jt) throws SQLException{
		Connection connection =  ConnectionFactory.getConnection();
	
        PreparedStatement ps1,ps2;
		ResultSet rs1,rs2;   
	
        try{
            sql2="SELECT * FROM T_ENDERECO";
            sql = "SELECT * FROM T_ORGANIZACAO";
            
            ps1 = connection.prepareStatement(sql); //faz pesquisa
			rs1= ps1.executeQuery(sql); //armazena resultado
            
            ps2 = connection.prepareStatement(sql2); //faz pesquisa
			rs2= ps2.executeQuery(sql2); //armazena resultado
            
            DefaultTableModel m = (DefaultTableModel) jt.getModel();
        
            while (rs1.next()&& rs2.next()){
                m.addRow(new String []{rs1.getString(("cd_org")),
                rs1.getString(("razao_social")),rs1.getString(("cnpj")),rs1.getString(("ds_email")),
                rs2.getString(("ds_bairro")),rs2.getString(("tipo_logradouro")),rs2.getString(("ds_logradouro")),rs2.getString(("numero")),
                rs2.getString(("complemento")),rs2.getString(("cep"))});	
            }
		   
            ps1.close();
            ps2.close();
	   }
		 
	    finally{
		connection.close();
	    }
    }
    
    public void limparTabela(JTable jt){
        DefaultTableModel m = (DefaultTableModel) jt.getModel();
        while (jt.getModel().getRowCount() > 0) {  
           ((DefaultTableModel) jt.getModel()).removeRow(0);  
        }
    }
    
    public void deletar(JLabel lbl) throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
        PreparedStatement ps;   
		
	try{
		
	    ps = connection.prepareStatement("DELETE FROM T_ORGANIZACAO WHERE cd_org=?");
	    ps.setInt(1, Integer.parseInt(lbl.getText()));
	            
	    ps.executeUpdate();
	    ps.close();
            
            //deleta também T_ENDERECO vinculado a ela
	}	 
        finally{
            connection.close();
        }
    }
    
    public void pesquisaORG_SETOR(JComboBox cb)throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
	
        PreparedStatement ps1;
	ResultSet rs1;
        
        try{
            sql = "SELECT * FROM T_ORGANIZACAO";
            
            ps1 = connection.prepareStatement(sql); //faz pesquisa
	    rs1= ps1.executeQuery(sql); //armazena resultado
            
            DefaultComboBoxModel c = (DefaultComboBoxModel) cb.getModel();
            while (rs1.next()){
               	c.addElement(rs1.getString(("razao_social")));
            }
		   
            ps1.close();
	   }
		 
	    finally{
		connection.close();
	    }
        
    }
    public void pesquisaORG_SETOR_PARTE2(JComboBox cb,JLabel lb)throws SQLException{
            if(cb.getSelectedItem() == "SELECIONE"){
                
            }
            else{
            Connection connection =  ConnectionFactory.getConnection();
	
            PreparedStatement ps1;
            ResultSet rs1;
        
            try{
                sql = "SELECT * FROM T_ORGANIZACAO WHERE razao_social='"+cb.getSelectedItem()+"' ;";
            
                ps1 = connection.prepareStatement(sql); //faz pesquisa
                rs1= ps1.executeQuery(sql); //armazena resultado
                while (rs1.next()){
                    lb.setText(rs1.getString(("cd_org")));
                }
                ps1.close();
            }
		 
	    finally{
		connection.close();
	    }
            }
    }
}
