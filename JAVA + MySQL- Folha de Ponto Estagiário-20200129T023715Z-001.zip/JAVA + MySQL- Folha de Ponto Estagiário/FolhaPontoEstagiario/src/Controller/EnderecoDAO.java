/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Controller;

import DataBase.ConnectionFactory;
import Model.T_Endereco;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JLabel;

/**
 *
 * @author Miche1
 */
public class EnderecoDAO {
    String sql;
    public void inserir(T_Endereco endereco) throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
        sql = "INSERT INTO T_ENDERECO VALUES (null,?,?,?,?,?,?,null)";
        PreparedStatement pst = connection.prepareStatement(sql);
        try{
            
            pst.setString(1, endereco.getBairro());
            pst.setString(2, endereco.getLogradouro());
            pst.setString(3, endereco.getDsLogradouro());
            pst.setInt(4, endereco.getNumero());
            pst.setString(5, endereco.getComplemento());
            pst.setString(6, endereco.getCep());
            
            pst.executeUpdate();
	    pst.close();
        }
        finally{
            connection.close();
        }
    }
    
    public void atualizar(T_Endereco endereco,JLabel lbl1, JLabel lbl2) throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
	PreparedStatement ps;
	
        try{
		
            ps = connection.prepareStatement("UPDATE T_ENDERECO SET ds_bairro=? ,"
                    + "tipo_logradouro=? ,ds_logradouro=? , numero=?, "
                    + "complemento=? ,cep=? ,cd_org=? WHERE cd_endereco=?"); 
                    
            ps.setString(1, endereco.getBairro());
            ps.setString(2, endereco.getLogradouro());
            ps.setString(3, endereco.getDsLogradouro());
            ps.setInt(4, endereco.getNumero());
            ps.setString(5, endereco.getComplemento());
            ps.setString(6, endereco.getCep());
            ps.setInt(7, Integer.parseInt(lbl1.getText()));
            ps.setInt(8, Integer.parseInt(lbl2.getText()));
            ps.executeUpdate();
            ps.close();
        }
        finally{
            connection.close();
	}
    }
}
