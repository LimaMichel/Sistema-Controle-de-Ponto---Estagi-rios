/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Controller;

import DataBase.ConnectionFactory;
import Model.T_Estagiario;
import Model.T_Organizacao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Miche1
 */
public class EstagiarioDAO {
    String sql;
    public void inserir(T_Estagiario estagiario) throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
        sql = "INSERT INTO T_ESTAGIARIO VALUES (null,?,?,?,?,?,?)";
        PreparedStatement pst = connection.prepareStatement(sql);
        try{
            pst.setInt(1, estagiario.getCodigoSetor());
            pst.setString(2, estagiario.getNomeEstagiario());
            pst.setString(3, estagiario.getSexo());
            pst.setString(4, estagiario.getRg());
            pst.setString(5, estagiario.getDt_nasto());
            pst.setString(6, estagiario.getDt_admissao());
            
            pst.executeUpdate();
	    pst.close();
        }
        finally{
            connection.close();
        }
    }
    
    public void atualizar(T_Estagiario estagiario,JLabel lbl) throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
	PreparedStatement pst;
	
        try{
		
            pst = connection.prepareStatement("UPDATE T_ESTAGIARIO SET cd_setor=?,nm_estagiario=?,ds_sexo=?,"
                    + "rg_estagiario=?, dt_nascimento=?, dt_admissao=? WHERE cd_estagiario=?");
            
            pst.setInt(1, estagiario.getCodigoSetor());
            pst.setString(2, estagiario.getNomeEstagiario());
            pst.setString(3, estagiario.getSexo());
            pst.setString(4, estagiario.getRg());
            pst.setString(5, estagiario.getDt_nasto());
            pst.setString(6, estagiario.getDt_admissao());
            pst.setInt(7, Integer.parseInt(lbl.getText()));
            
            pst.executeUpdate();
            pst.close();
        }
        finally{
            connection.close();
	}
    }
    
    public void pesquisar(JTable jt) throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
	
        PreparedStatement ps1;
	ResultSet rs1;   
	
        try{
            sql = "SELECT * FROM T_ESTAGIARIO";
            
            ps1 = connection.prepareStatement(sql); //faz pesquisa
	    rs1= ps1.executeQuery(sql); //armazena resultado
            
            DefaultTableModel m = (DefaultTableModel) jt.getModel();
        
            while (rs1.next()){
                m.addRow(new String []{rs1.getString(("cd_estagiario")),
                rs1.getString(("cd_setor")),rs1.getString(("nm_estagiario")),
                rs1.getString(("ds_sexo")),rs1.getString(("rg_estagiario")),
                rs1.getString(("dt_nascimento")),rs1.getString(("dt_admissao"))});	
            }

            ps1.close();
	}
		 
	finally{
            connection.close();
	}
    }
    
    //Para view FolhadePonto
    public void pesquisar2(JTable jt, JLabel lbl) throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
	
        PreparedStatement ps1;
	ResultSet rs1;   
	
        try{
            sql = "SELECT * FROM T_ESTAGIARIO WHERE cd_setor="+lbl.getText()+";";
            
            ps1 = connection.prepareStatement(sql); //faz pesquisa
	    rs1= ps1.executeQuery(sql); //armazena resultado
            
            DefaultTableModel m = (DefaultTableModel) jt.getModel();
        
            while (rs1.next()){
                m.addRow(new String []{rs1.getString(("cd_estagiario")),
                rs1.getString(("nm_estagiario"))});	
            }

            ps1.close();
	}
		 
	finally{
            connection.close();
	}
    }
    
    //Para view FolhadePonto
    public String pesquisar3(JLabel cdEsta) throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
	
        PreparedStatement ps1;
	ResultSet rs1;   
	String aux="";
        try{
            sql = "SELECT dt_admissao FROM T_ESTAGIARIO WHERE cd_estagiario="+cdEsta.getText()+";";
            
            ps1 = connection.prepareStatement(sql); //faz pesquisa
	    rs1= ps1.executeQuery(sql); //armazena resultado
            if(rs1.next()){
               aux = rs1.getString(("dt_admissao")); 
            }
            
            ps1.close();
	}
		 
	finally{
            connection.close();
	}
        return aux;
    }
    public void limparTabela(JTable jt)throws SQLException{
        DefaultTableModel m = (DefaultTableModel) jt.getModel();
        while (jt.getModel().getRowCount() > 0) {  
           ((DefaultTableModel) jt.getModel()).removeRow(0);  
        }   
    }
    
    //para view FPSuoervisor
    public void pesquisar4(JComboBox cb,JLabel lbl) throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
	
        PreparedStatement ps1;
	ResultSet rs1;   
	
        try{
            sql = "SELECT * FROM T_ESTAGIARIO WHERE cd_setor="+lbl.getText()+";";
            
            ps1 = connection.prepareStatement(sql); //faz pesquisa
	    rs1= ps1.executeQuery(sql); //armazena resultado
            
            DefaultComboBoxModel c = (DefaultComboBoxModel) cb.getModel();
            while (rs1.next()){
               	c.addElement(rs1.getString(("nm_estagiario")));
            }
            ps1.close();
	}
		 
	    finally{
		connection.close();
	    }
        
    }
    
    public void pesquisar5(JComboBox cb,JLabel lbl, JLabel lbl2) throws SQLException{
        if(cb.getSelectedItem() == "SELECIONE"){
            
        }
        else{
        Connection connection =  ConnectionFactory.getConnection();
	
        PreparedStatement ps1;
	ResultSet rs1;   
	
        try{
            sql = "SELECT * FROM T_ESTAGIARIO WHERE nm_estagiario='"+cb.getSelectedItem()+"' and cd_setor="+lbl.getText()+" ;";
            
            ps1 = connection.prepareStatement(sql); //faz pesquisa
	    rs1= ps1.executeQuery(sql); //armazena resultado
            
            DefaultComboBoxModel c = (DefaultComboBoxModel) cb.getModel();
            while (rs1.next()){
               	lbl2.setText(rs1.getString(("cd_estagiario")));
            }
            ps1.close();
	}
		 
	    finally{
		connection.close();
	    }
        }
    }
    
    public void deletar(JLabel lbl) throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
        PreparedStatement ps;   
		
	try{	
	    ps = connection.prepareStatement("DELETE FROM T_ESTAGIARIO WHERE cd_estagiario=?");
	    ps.setInt(1, Integer.parseInt(lbl.getText()));
	            
	    ps.executeUpdate();
	    ps.close();
	}	 
        finally{
            connection.close();
        }
    }
    
    public String acesso(String senha,JLabel lbl) throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
	
        PreparedStatement ps1;
	ResultSet rs1;   
	String rg="";
        try{
            sql = "SELECT rg_estagiario FROM T_ESTAGIARIO WHERE rg_estagiario='"+senha+"' and cd_estagiario="+lbl.getText()+" ;";
            
            ps1 = connection.prepareStatement(sql); //faz pesquisa
	    rs1= ps1.executeQuery(sql); //armazena resultado
            
            while (rs1.next()){
               	rg = rs1.getString(("rg_estagiario"));
            }
            ps1.close();
	}
		 
	finally{
            connection.close();
	}
        
        return rg; 
    }
}
