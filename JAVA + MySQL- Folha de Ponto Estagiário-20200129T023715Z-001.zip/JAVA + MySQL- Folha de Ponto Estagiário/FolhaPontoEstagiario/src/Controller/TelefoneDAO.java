/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Controller;

import DataBase.ConnectionFactory;
import Model.T_Telefone;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Miche1
 */
public class TelefoneDAO {
    String sql;
    public void inserir(T_Telefone telefone) throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
        sql = "INSERT INTO T_TELEFONE VALUES (null,?,?,?,?)";
        PreparedStatement pst = connection.prepareStatement(sql);
        try{
            pst.setString(1, telefone.getCodigoPais());
            pst.setInt(2, telefone.getDddTelefone());
            pst.setInt(3, telefone.getNumeroTelefone());
            pst.setInt(4, telefone.getCodSetor());
            
            pst.executeUpdate();
	    pst.close();
        }
        finally{
            connection.close();
        }
    }
    
    public void atualizar(T_Telefone telefone, JLabel lbl) throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
	PreparedStatement ps;
	
        try{
		
            ps = connection.prepareStatement("UPDATE T_TELEFONE SET cd_pais=?,ddd_telefone=?,nr_telefone=?,cd_setor=? WHERE cd_telefone=?");

            ps.setString(1, telefone.getCodigoPais());
            ps.setInt(2, telefone.getDddTelefone());
            ps.setInt(3, telefone.getNumeroTelefone());
            ps.setInt(4, telefone.getCodSetor());
            ps.setInt(5, Integer.parseInt(lbl.getText()));
            
            ps.executeUpdate();
            ps.close();
        }
        finally{
            connection.close();
	}
    }
    
    public void pesquisar(JTable jt) throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
	
        PreparedStatement ps1;
	ResultSet rs1;   
	
        try{
            sql = "SELECT * FROM T_TELEFONE";
            
            ps1 = connection.prepareStatement(sql); //faz pesquisa
	    rs1= ps1.executeQuery(sql); //armazena resultado
            
            DefaultTableModel m = (DefaultTableModel) jt.getModel();
        
            while (rs1.next()){
                m.addRow(new String []{rs1.getString(("cd_setor")),
                rs1.getString(("cd_pais")),rs1.getString(("ddd_telefone")),
                rs1.getString(("nr_telefone")),rs1.getString(("cd_telefone"))});	
            }
            ps1.close();
	}
		 
	    finally{
		connection.close();
	    }
    }
    
    public void limparTabela(JTable jt)throws SQLException{
        DefaultTableModel m = (DefaultTableModel) jt.getModel();
        while (jt.getModel().getRowCount() > 0) {  
           ((DefaultTableModel) jt.getModel()).removeRow(0);  
        }   
    }
    
    public void deletar(JLabel lbl) throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
        PreparedStatement ps;   
		
	try{	
	    ps = connection.prepareStatement("DELETE FROM T_TELEFONE WHERE cd_telefone=?");
	    ps.setInt(1, Integer.parseInt(lbl.getText()));
	            
	    ps.executeUpdate();
	    ps.close();
	}	 
        finally{
            connection.close();
        }
    }
}
