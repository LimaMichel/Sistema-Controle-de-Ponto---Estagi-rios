/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Controller;

import View.Organizacao;
import javax.swing.JOptionPane;

/**
 *
 * @author Miche1
 */
public class Main {
   
    public static void main(String args[]){
        
        Menu menu = new Menu();
        menu.setVisible(true);
    }
}
