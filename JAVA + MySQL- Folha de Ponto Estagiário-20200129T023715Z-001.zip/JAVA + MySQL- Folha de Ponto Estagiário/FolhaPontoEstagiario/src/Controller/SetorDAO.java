/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Controller;

import DataBase.ConnectionFactory;
import Model.T_Organizacao;
import Model.T_Setor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Miche1
 */
public class SetorDAO {
    String sql;
    public void inserir(T_Setor setor, JLabel lbl) throws SQLException{
       Connection connection =  ConnectionFactory.getConnection();
        sql = "INSERT INTO T_SETOR VALUES (null,?,?)";
        PreparedStatement pst = connection.prepareStatement(sql);
        try{
            pst.setInt(1, Integer.parseInt(lbl.getText()));
            pst.setString(2, setor.getNomeSetor());
            
            pst.executeUpdate();
	    pst.close();
        }
        finally{
            connection.close();
        }
    }
    
    public void atualizar(T_Setor setor, JLabel lbl1, JLabel lbl2) throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
	PreparedStatement ps;
	
        try{
		
            ps = connection.prepareStatement("UPDATE T_SETOR SET cd_org=?,nm_setor=? WHERE cd_setor=?");
	    	
            ps.setInt(1, Integer.parseInt(lbl1.getText()));
            ps.setString(2, setor.getNomeSetor());
            ps.setInt(3, Integer.parseInt(lbl2.getText()));
            
            ps.executeUpdate();
            ps.close();
        }
        finally{
            connection.close();
	}
    }
    
    public void pesquisar(JTable jt) throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
	
        PreparedStatement ps1;
	ResultSet rs1;   
	
        try{
            sql = "SELECT * FROM T_SETOR";
            
            ps1 = connection.prepareStatement(sql); //faz pesquisa
	    rs1= ps1.executeQuery(sql); //armazena resultado
            
            DefaultTableModel m = (DefaultTableModel) jt.getModel();
        
            while (rs1.next()){
                m.addRow(new String []{rs1.getString(("cd_org")),
                rs1.getString(("cd_setor")),rs1.getString(("nm_setor"))});	
            }
            ps1.close();
	}
		 
	    finally{
		connection.close();
	    }
    }
    
    //Pesquisar para View Estagiario
    public void pesquisar2(JTable jt,JLabel lb) throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
	
        PreparedStatement ps1;
	ResultSet rs1;   
	
        try{
            sql = "SELECT * FROM T_SETOR WHERE cd_org="+lb.getText()+"";
            
            ps1 = connection.prepareStatement(sql); //faz pesquisa
	    rs1= ps1.executeQuery(sql); //armazena resultado
            
            DefaultTableModel m = (DefaultTableModel) jt.getModel();
        
            while (rs1.next()){
                m.addRow(new String []{rs1.getString(("cd_org")),
                rs1.getString(("cd_setor")),rs1.getString(("nm_setor"))});	
            }
            ps1.close();
	}
		 
	    finally{
		connection.close();
	    }
    }
    
    //Pesquisar para view FolhadePonto
    public void pesquisar3(JComboBox cb,JLabel lbl) throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
	
        PreparedStatement ps1;
	ResultSet rs1;   
	
        try{
            sql = "SELECT * FROM T_SETOR WHERE cd_org="+lbl.getText()+"";
            
            ps1 = connection.prepareStatement(sql); //faz pesquisa
	    rs1= ps1.executeQuery(sql); //armazena resultado
            
            DefaultComboBoxModel c = (DefaultComboBoxModel) cb.getModel();
            while (rs1.next()){
               	c.addElement(rs1.getString(("nm_setor")));
            }
            ps1.close();
	}
		 
	    finally{
		connection.close();
	    }
        
    }
    
    public void pesquisaSETOR_PARTE2(JComboBox cb,JLabel lb,JLabel lb2)throws SQLException{
            if(cb.getSelectedItem() == "SELECIONE"){
                
            }
            else{
            Connection connection =  ConnectionFactory.getConnection();
	
            PreparedStatement ps1;
            ResultSet rs1;
        
            try{
                sql = "SELECT * FROM T_SETOR WHERE nm_setor='"+cb.getSelectedItem()+"' and cd_org="+lb.getText()+";";
            
                ps1 = connection.prepareStatement(sql); //faz pesquisa
                rs1= ps1.executeQuery(sql); //armazena resultado
                while (rs1.next()){
                    lb2.setText(rs1.getString(("cd_setor")));
                }
                ps1.close();
            }
		 
	    finally{
		connection.close();
	    }   
            }
    }
    
    public void limparTabela(JTable jt)throws SQLException{
        DefaultTableModel m = (DefaultTableModel) jt.getModel();
        while (jt.getModel().getRowCount() > 0) {  
           ((DefaultTableModel) jt.getModel()).removeRow(0);  
        }   
    }
    
    
    public void deletar(JLabel lbl) throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
        PreparedStatement ps;   
		
	try{	
	    ps = connection.prepareStatement("DELETE FROM T_SETOR WHERE cd_setor=?");
	    ps.setInt(1, Integer.parseInt(lbl.getText()));
	            
	    ps.executeUpdate();
	    ps.close();
	}	 
        finally{
            connection.close();
        }
    }
}
