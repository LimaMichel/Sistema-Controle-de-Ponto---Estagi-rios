/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Controller;

import DataBase.ConnectionFactory;
import Model.T_Organizacao;
import Model.T_Supervisor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author x527556
 */
public class SupervisorDAO {
    String sql;
    public void inserir(T_Supervisor supervisor) throws SQLException{
        
        Connection connection =  ConnectionFactory.getConnection();
        sql = "INSERT INTO T_SUPERVISOR VALUES (null,?,?,?,?)";
        PreparedStatement pst = connection.prepareStatement(sql);
        try{
            pst.setString(1, supervisor.getRfSupervisor());
            pst.setInt(2, supervisor.getCdOrg());
            pst.setString(3, supervisor.getNomeSupervisor());
            pst.setString(4, supervisor.getDt_admis());
            
            pst.executeUpdate();
	    pst.close();
        }
        finally{
            connection.close();
        }
    }
    
    public void atualizar(T_Supervisor supervisor, JLabel lbl) throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
	PreparedStatement ps;
	
        try{
		
            ps = connection.prepareStatement("UPDATE  T_SUPERVISOR SET rf_supervisor=?, cd_org=?, nome_supervisor=?, dt_admis=? WHERE cd_supervisor=?");
	    	
            ps.setString(1, supervisor.getRfSupervisor());
            ps.setInt(2, supervisor.getCdOrg());
            ps.setString(3, supervisor.getNomeSupervisor());
            ps.setString(4, supervisor.getDt_admis());
            ps.setInt(5, Integer.parseInt(lbl.getText()));
            
            ps.executeUpdate();
            ps.close();
        }
        finally{
            connection.close();
	}
    }
    
    public void pesquisar(JTable jt) throws SQLException{
	DefaultTableModel m = (DefaultTableModel) jt.getModel();
        while (jt.getModel().getRowCount() > 0) {  
           ((DefaultTableModel) jt.getModel()).removeRow(0);  
        }
        
        
        Connection connection =  ConnectionFactory.getConnection();
	
        PreparedStatement ps1;
	ResultSet rs1;   
	
        try{
            sql = "SELECT * FROM T_SUPERVISOR";
            
            ps1 = connection.prepareStatement(sql); //faz pesquisa
	    rs1= ps1.executeQuery(sql); //armazena resultado
        
            while (rs1.next()){
                m.addRow(new String []{rs1.getString(("cd_supervisor")),
                rs1.getString(("rf_supervisor")),rs1.getString(("cd_org")),rs1.getString(("nome_supervisor")),
                rs1.getString(("dt_admis"))});	
            }
		   
            ps1.close();
	   }
		 
	    finally{
		connection.close();
	    }
    }
    
    public void deletar(JLabel lbl) throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
        PreparedStatement ps;   
		
	try{
		
	    ps = connection.prepareStatement("DELETE FROM  T_SUPERVISOR WHERE cd_supervisor=?");
	    ps.setInt(1, Integer.parseInt(lbl.getText()));
	            
	    ps.executeUpdate();
	    ps.close();
	}	 
        finally{
            connection.close();
        }
    }
    
    public int pesquisarRF(String rf) throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
	
        PreparedStatement ps1;
	ResultSet rs1;   
	int result=1;
        try{
            sql = "SELECT * FROM T_SUPERVISOR WHERE rf_supervisor='"+rf+"' ;";
            
            ps1 = connection.prepareStatement(sql); //faz pesquisa
	    rs1= ps1.executeQuery(sql); //armazena resultado
        
            while (rs1.next()){
                rs1.getString(("rf_supervisor"));
                result = 2;
            }
		   
            ps1.close();
	   }
		 
	    finally{
		connection.close();
	    }
        return result;
    }
}


