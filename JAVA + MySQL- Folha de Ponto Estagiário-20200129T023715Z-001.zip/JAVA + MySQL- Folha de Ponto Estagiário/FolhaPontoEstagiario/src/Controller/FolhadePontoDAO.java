/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Controller;

import DataBase.ConnectionFactory;
import Model.T_FolhadePonto;
import Model.T_PontoAssinado;

import java.io.*;
import java.sql.*;
import java.text.*;
import java.util.*;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

/**
 *
 * @author Miche1
 */

public class FolhadePontoDAO {
    String sql;
    public int inserir(T_FolhadePonto folhaponto) throws SQLException{
        
        Connection connection =  ConnectionFactory.getConnection();
        sql = "INSERT INTO T_FOLHA_PONTO VALUES (null,?,?,?)";
        PreparedStatement pst = connection.prepareStatement(sql);
        try{
            
            pst.setString(1, folhaponto.getDt_folhaponto());
            pst.setInt(2, folhaponto.getCd_estagiario());
            pst.setString(3, folhaponto.getSituacao());
            
            pst.executeUpdate();
	    pst.close();
            
            sql = "SELECT cd_fp FROM T_FOLHA_PONTO WHERE dt_folha_ponto='"+folhaponto.getDt_folhaponto()+"' ;";
        
            pst = connection.prepareStatement(sql); //faz pesquisa
            ResultSet rs1 = pst.executeQuery(sql); //armazena resultado
            int cd_fp = 0;
            while (rs1.next()){
                cd_fp = Integer.parseInt(rs1.getString(("cd_fp")));
            }
		   
            pst.close();
            
            return cd_fp;
        }
        finally{
            connection.close();
        }
    }
    
    public int pesquisar(JFormattedTextField dt_fp, JLabel cd_esta) throws SQLException{
	Connection connection =  ConnectionFactory.getConnection();
	
        PreparedStatement ps1;
	ResultSet rs1;   
	int aux=0;
        try{
            sql = "SELECT * FROM T_FOLHA_PONTO WHERE dt_folha_ponto='"+dt_fp.getText()+"' and cd_estagiario="
                    +cd_esta.getText()+";";
            
            ps1 = connection.prepareStatement(sql); //faz pesquisa
	    rs1= ps1.executeQuery(sql); //armazena resultado
        
            while (rs1.next()){
               rs1.getString(("dt_folha_ponto"));
               if(rs1.getString(("dt_folha_ponto")) != null){
                   aux=1;
               }
            }
		   
            ps1.close();
	   }
		 
	    finally{
		connection.close();
	    }
        
            return aux;
    }
    
    public void inserirPontoAss(T_PontoAssinado pontoAss) throws SQLException{
        
        Connection connection =  ConnectionFactory.getConnection();
        sql = "INSERT INTO T_PONTO_ASSINADO VALUES (null,?,?,?,?,?)";
        PreparedStatement pst = connection.prepareStatement(sql);
        try{
            
            //pst.setInt(1, pontoAss.getCd_ponto_ass());
            pst.setString(1, pontoAss.getHr_entrada());
            pst.setString(2, pontoAss.getHr_saida());
            pst.setString(3, pontoAss.getObs());
            pst.setInt(4, pontoAss.getCd_fp());
            pst.setString(5, pontoAss.getDt_folhaponto());
            
            pst.executeUpdate();
	    pst.close();
        }
        finally{
            connection.close();
        }
    }
    
    public ArrayList setDATAinserir(JFormattedTextField txtDataFolhaPonto) throws ParseException{
        
            String aux = txtDataFolhaPonto.getText();

            int dia = 0;
            int mes=Integer.parseInt(aux.substring(0,2));
            int ano=Integer.parseInt(aux.substring(3,7));

            
            if(ano %4 == 0){
                //bissesto
                if(mes == 2){
                    dia=29;
                }
                
                if(mes == 4 || mes == 6 || mes == 9 || mes == 11){
                    dia=30;
                }
                if(mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes == 8 || mes == 10 || mes == 11 || mes == 12){
                    dia=31;  
                }
                
            }
            else{
                if(mes == 2){
                    dia=28;
                }
                
                if(mes == 4 || mes == 6 || mes == 9 || mes == 11){
                    dia=30;
                }
                
                if(mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes == 8 || mes == 10 || mes == 11 || mes == 12){
                    dia=31;  
                }
            }
            
            ArrayList data = new ArrayList<>();
            
            for(int i=0; i<dia; i++){
               
                //montando a data
                String data_ponto = i+1+"/"+mes+"/"+ano;
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                Date dt_final = sdf.parse(data_ponto);
                
                //verificando final de semana
                Calendar cal = Calendar.getInstance();
                cal.setTime(dt_final);
                int day = cal.get(Calendar.DAY_OF_WEEK);
                
                if(day != 1 && day != 7){
                  data.add(data_ponto);  
                }
                else{
                    if(day == 1){
                        data.add("DOMINGO-"+data_ponto);
                    }
                    else{
                        data.add("SABADO-"+data_ponto);
                    }
                }
                
            }
            
            return data;
    }
    
    public void atualizarTabelaPontoASS(JTable jt, JLabel jft) throws SQLException{
        
        //limpando
        while (jt.getModel().getRowCount() > 0) {  
           ((DefaultTableModel) jt.getModel()).removeRow(0);  
        }
        
        //add
        Connection connection =  ConnectionFactory.getConnection();
	
        PreparedStatement ps1;
	ResultSet rs1;   
	
        try{
            sql = "SELECT * FROM T_PONTO_ASSINADO WHERE cd_fp="+jft.getText()+";";
            
            ps1 = connection.prepareStatement(sql); //faz pesquisa
	    rs1= ps1.executeQuery(sql); //armazena resultado
            
            DefaultTableModel m = (DefaultTableModel) jt.getModel();
        
            while (rs1.next()){
                m.addRow(new String []{rs1.getString(("cd_ponto_ass")),rs1.getString(("dt_folha_ponto")),
                rs1.getString(("obs")),rs1.getString(("hr_entrada")),rs1.getString(("hr_saida"))});	
            }

            ps1.close();
	}
		 
	finally{
            connection.close();
	}
    }
    public void atualizarTabelaFolhaPonto(JTable jt, JLabel lbl) throws SQLException{
        //limpando
        while (jt.getModel().getRowCount() > 0) {  
           ((DefaultTableModel) jt.getModel()).removeRow(0);  
        }
        
        //add
        Connection connection =  ConnectionFactory.getConnection();
	
        PreparedStatement ps1;
	ResultSet rs1;   
	
        try{
            sql = "SELECT * FROM T_FOLHA_PONTO WHERE cd_estagiario="+lbl.getText()+";";
            
            ps1 = connection.prepareStatement(sql); //faz pesquisa
	    rs1= ps1.executeQuery(sql); //armazena resultado
            
            DefaultTableModel m = (DefaultTableModel) jt.getModel();
        
    
    
    
            while (rs1.next()){
                m.addRow(new String []{rs1.getString(("cd_fp")),
                rs1.getString(("dt_folha_ponto")),rs1.getString(("cd_estagiario")),
                rs1.getString(("situacao"))});	
            }
            ps1.close();
	}
		 
	    finally{
		connection.close();
	    }
    }
    
    public void atualizarTabelaPontoASS_EST(JTable jt, JLabel jft) throws SQLException{
        
        //limpando
        while (jt.getModel().getRowCount() > 0) {  
           ((DefaultTableModel) jt.getModel()).removeRow(0);  
        }
        
        //add
        Connection connection =  ConnectionFactory.getConnection();
	
        PreparedStatement ps1;
	ResultSet rs1;   
        try{
            
            sql = "SELECT cd_fp FROM T_FOLHA_PONTO WHERE cd_estagiario='"+jft.getText()+"' and situacao='ABERTO' ;";
        
            ps1 = connection.prepareStatement(sql); //faz pesquisa
            rs1 = ps1.executeQuery(sql); //armazena resultado
            int cd_fp = 0;
            while (rs1.next()){
                cd_fp = Integer.parseInt(rs1.getString(("cd_fp")));
            }
            
            sql = "SELECT * FROM T_PONTO_ASSINADO WHERE cd_fp="+cd_fp+"  and obs != 'RECESSO' and obs != '----------' ;";
            
            ps1 = connection.prepareStatement(sql); //faz pesquisa
	    rs1= ps1.executeQuery(sql); //armazena resultado
            
            DefaultTableModel m = (DefaultTableModel) jt.getModel();
        
            while (rs1.next()){
                m.addRow(new String []{rs1.getString(("cd_ponto_ass")),rs1.getString(("dt_folha_ponto")),
                rs1.getString(("obs")),rs1.getString(("hr_entrada")),rs1.getString(("hr_saida"))});	
            }

            ps1.close();
	}
		 
	finally{
            connection.close();
	}
    }
    
    public void limparTabela(JTable jt){
        //limpando
        while (jt.getModel().getRowCount() > 0) {  
           ((DefaultTableModel) jt.getModel()).removeRow(0);  
        }
    }
    
    public void deletar(JLabel lbl) throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
        PreparedStatement ps;   
		
	try{	
	    ps = connection.prepareStatement("DELETE FROM T_FOLHA_PONTO WHERE cd_fp=?");
	    ps.setInt(1, Integer.parseInt(lbl.getText()));
	            
	    ps.executeUpdate();
	    ps.close();
	}	 
        finally{
            connection.close();
        }
    }
    
    public void atualizar(JLabel lbl,int op) throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
	PreparedStatement pst;
	String obs = null;
        if(op == 1){
            obs="RECESSO";
        }
        if(op == 0){
            obs="ASSINAR";
        }
        try{
		
            pst = connection.prepareStatement("UPDATE T_PONTO_ASSINADO SET obs=? WHERE cd_ponto_ass=?");
            
            pst.setString(1, obs);
            pst.setInt(2, Integer.parseInt(lbl.getText()));
            
            pst.executeUpdate();
            pst.close();
        }
        finally{
            connection.close();
	}
    }
    
    public void Assinar_EST(String hr_ent, String hr_sai, String obs, int cdfp) throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
	PreparedStatement pst;
        try{
		
            pst = connection.prepareStatement("UPDATE T_PONTO_ASSINADO SET hr_entrada=?, hr_saida=?, obs=? WHERE cd_ponto_ass=?");
            
            pst.setString(1, hr_ent);
            pst.setString(2, hr_sai);
            if(obs.equals("")){
                pst.setString(3, "ASSINADO");
            }
            else{
                pst.setString(3, obs);
            }
            pst.setInt(4, cdfp);
            
            pst.executeUpdate();
            pst.close();
        }
        finally{
            connection.close();
	}
    }
    
    public void gerarArquivo(JLabel lblest, JLabel lblset, JLabel lblorg, JLabel lblfp) throws IOException, DocumentException, SQLException{
        //PESQUISANDO DADOS
        String estagiario = null, setor = null, organizacao = null;
        String sql1,sql2,sql3;
        Connection connection =  ConnectionFactory.getConnection();
	
        PreparedStatement ps1;
	ResultSet rs1;
        
        sql1 = "SELECT nm_estagiario, rg_estagiario FROM T_ESTAGIARIO WHERE cd_estagiario="+lblest.getText()+" ;";
        sql2 = "SELECT nm_setor FROM T_SETOR WHERE cd_setor="+lblset.getText()+" ;";
        sql3 = "SELECT razao_social, cnpj FROM T_ORGANIZACAO WHERE cd_org="+lblorg.getText()+" ;";
        
        //estagiario
        ps1 = connection.prepareStatement(sql1);
	rs1= ps1.executeQuery(sql1);   
        String esta="";
        while (rs1.next()){
            estagiario = rs1.getString(("nm_estagiario"))+ "  RG: "+rs1.getString(("rg_estagiario"));
            esta = rs1.getString(("nm_estagiario"))+"-";
        }
        
        //setor
        ps1 = connection.prepareStatement(sql2);
	rs1= ps1.executeQuery(sql2);   
        
        while (rs1.next()){
            setor = rs1.getString(("nm_setor"));	
        }
        
        //organizacao
        ps1 = connection.prepareStatement(sql3);
	rs1= ps1.executeQuery(sql3);   
        
        while (rs1.next()){
            organizacao = rs1.getString(("razao_social"))+ "\n  CNPJ: "+rs1.getString(("cnpj"));	
        }
        
 
        
        /******************************GERANDO ARQUIVO********************************/
        Document pdf = new Document();
        
        String dir = System.getProperty("user.dir");
        File diretorio = new File(dir+"\\"+"ARQUIVO_FOLHA_PONTO\\"+setor);
        diretorio.mkdir();
        
        OutputStream gerar = new FileOutputStream(diretorio+"\\"+esta+lblfp.getText()+".pdf");
        
        PdfWriter.getInstance(pdf, gerar);
        
        pdf.open();

        Image img = Image.getInstance(dir+"\\src\\IMG\\LogoArquivo.jpg");
        img.setAlignment(Element.ALIGN_CENTER);
        pdf.add(img);
        
        Paragraph title = new Paragraph("\n\nFOLHA DE FREQUENCIA DO ESTAGIARIO - Assinada Eletronicamente\n\n\n");
        title.setAlignment(Element.ALIGN_CENTER);
        pdf.add(title);
        
        pdf.add(new Paragraph("ORGANIZAÇÃO: "+organizacao));
        pdf.add(new Paragraph("\nSETOR: "+setor));
        
        pdf.add(new Paragraph("\nESTAGIARIO: "+estagiario+"\n"));
        
        
        //folha de ponto assinado
        
        sql = "SELECT * FROM T_PONTO_ASSINADO WHERE cd_fp="+lblfp.getText()+" ;";
            
        ps1 = connection.prepareStatement(sql); //faz pesquisa
	rs1= ps1.executeQuery(sql); //armazena resultado
            
        while (rs1.next()){
            String dt = rs1.getString(("dt_folha_ponto"));
            String obs = rs1.getString(("obs"));
            String hr_Ent = rs1.getString(("hr_entrada"));
            String hr_Sai = rs1.getString(("hr_saida"));
            
            pdf.add(new Paragraph("\nDATA: "+dt+" |    SITUAÇÃO: "+obs+" |    HORA ENTRADA: "+hr_Ent+" |    HORA SAÍDA: "+hr_Sai));   	
        }
        
        
        ps1 = connection.prepareStatement("UPDATE T_FOLHA_PONTO SET situacao=? WHERE cd_fp=?");
            
        ps1.setString(1, "FECHADO");
        ps1.setInt(2, Integer.parseInt(lblfp.getText()));
              
        ps1.executeUpdate();
        ps1.close();
        connection.close();
        
        pdf.close();
    }
    
    public void atualizarSituacaoFolhaPonto(JLabel lblfp) throws SQLException{
        Connection connection =  ConnectionFactory.getConnection();
	
        PreparedStatement ps1 = connection.prepareStatement("UPDATE T_FOLHA_PONTO SET situacao=? WHERE cd_fp=?");
            
        ps1.setString(1, "ABERTO");
        ps1.setInt(2, Integer.parseInt(lblfp.getText()));
              
        ps1.executeUpdate();
        ps1.close();
        connection.close();
    }
}
